package work.torp.sonar.classes;

import java.sql.Timestamp;

public class SonarUsage {
	public String uuid;
	public Timestamp timestamp;
}
